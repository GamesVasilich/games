const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static(__dirname));

let players = {};

io.on('connection', (socket) => {
    console.log(`Игрок вошел: ${socket.id}`);

    socket.on('join', (data) => {
        players[socket.id] = {
            id: socket.id,
            name: data.name,
            x: data.x,
            y: data.y,
            z: data.z,
            hp: 100
        };
        socket.emit('currentPlayers', players);
        socket.broadcast.emit('newPlayer', players[socket.id]);
    });

    socket.on('move', (data) => {
        let p = players[socket.id];
        if (p) {
            p.x = Math.max(-145, Math.min(145, data.x));
            p.y = data.y;
            p.z = Math.max(-145, Math.min(145, data.z));
            socket.broadcast.emit('playerMoved', { id: socket.id, x: p.x, y: p.y, z: p.z });
        }
    });

    socket.on('shoot', () => {
        socket.broadcast.emit('playerShoot', { id: socket.id });
    });

    socket.on('hitPlayer', (data) => {
        let target = players[data.id];
        if (target) {
            target.hp -= data.damage;
            if (target.hp <= 0) {
                target.hp = 0;
                io.emit('playerKilled', { id: target.id });
            }
            io.emit('playerDamaged', { id: target.id, hp: target.hp });
        }
    });

    socket.on('respawnMe', () => {
        let p = players[socket.id];
        if (p) {
            p.hp = 100;
            p.x = (Math.random() - 0.5) * 40;
            p.z = (Math.random() - 0.5) * 40;
            io.emit('playerRespawned', { id: socket.id, x: p.x, z: p.z, hp: 100 });
        }
    });

    // Пинг-ответ для проверки связи
    socket.on('client_ping', () => {
        socket.emit('server_pong');
    });

    socket.on('disconnect', () => {
        delete players[socket.id];
        io.emit('disconnectPlayer', socket.id);
        console.log(`Игрок вышел: ${socket.id}`);
    });
});

const PORT = 1000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`Сервер запущен`);
});