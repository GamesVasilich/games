const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

app.use(express.static(__dirname));

let players = {};


const SERVER_WEAPONS = {
    "Пистолет": { damage: 25, maxDist: 45 },
    "Дробовик": { damage: 60, maxDist: 25 }, 
    "Автомат": { damage: 15, maxDist: 45 }
};

const MAX_SPEED = 12.0; 

io.on('connection', (socket) => {
    console.log(`Игрок вошел: ${socket.id}`);

    socket.on('join', (data) => {
        players[socket.id] = {
            id: socket.id,
            name: data.name || "Боец",
            x: data.x || 0,
            y: data.y || 1.5,
            z: data.z || 0,
            hp: 100,
            isDead: false,
            lastMoveTime: Date.now() 
        };
        socket.emit('currentPlayers', players);
        socket.broadcast.emit('newPlayer', players[socket.id]);
    });

    socket.on('move', (data) => {
        let p = players[socket.id];
        if (p && !p.isDead) {
            let now = Date.now();
            let deltaTime = (now - p.lastMoveTime) / 1000; 

            
            if (deltaTime > 0.01) {
                
                let dx = data.x - p.x;
                let dz = data.z - p.z;
                let distance = Math.hypot(dx, dz);
                let calculatedSpeed = distance / deltaTime;

                
                if (calculatedSpeed > MAX_SPEED) {
                    console.warn(`[Античит] Обнаружен спидхак/телепорт у игрока ${p.name}. Скорость: ${calculatedSpeed.toFixed(1)} м/с`);

                    
                    socket.emit('playerMoved', { id: socket.id, x: p.x, y: p.y, z: p.z });
                    p.lastMoveTime = now;
                    return;
                }
            }

            p.x = Math.max(-145, Math.min(145, data.x));
            p.y = data.y;
            p.z = Math.max(-145, Math.min(145, data.z));
            p.lastMoveTime = now;

            socket.broadcast.emit('playerMoved', { id: socket.id, x: p.x, y: p.y, z: p.z });
        }
    });

    socket.on('shoot', () => {
        let p = players[socket.id];
        if (p && !p.isDead) {
            socket.broadcast.emit('playerShoot', { id: socket.id });
        }
    });

    socket.on('hitPlayer', (data) => {
        let shooter = players[socket.id];
        let target = players[data.id];

        if (shooter && !shooter.isDead && target && !target.isDead) {
            let weaponStats = SERVER_WEAPONS[data.weaponName] || { damage: 15, maxDist: 45 };

            let distToTarget = Math.hypot(target.x - shooter.x, target.z - shooter.z);

            if (distToTarget > weaponStats.maxDist) {
                console.warn(`[Античит] Игрок ${shooter.name} пытался нанести урон на запрещенной дистанции: ${distToTarget.toFixed(1)}м из ${data.weaponName}`);
                return; 
            }

            target.hp -= weaponStats.damage;

            if (target.hp <= 0) {
                target.hp = 0;
                target.isDead = true;
                io.emit('playerKilled', { id: target.id, killedBy: socket.id });
            }

            io.emit('playerDamaged', { id: target.id, hp: target.hp });
        }
    });

    socket.on('respawnMe', () => {
        let p = players[socket.id];
        if (p && p.isDead) {
            p.hp = 100;
            p.isDead = false;
            p.x = (Math.random() - 0.5) * 40;
            p.y = 1.5; 
            p.z = (Math.random() - 0.5) * 40;
            p.lastMoveTime = Date.now();

            io.emit('playerRespawned', { id: socket.id, x: p.x, y: p.y, z: p.z, hp: 100 });
        }
    });


    socket.on('client_ping', () => {
        socket.emit('server_pong');
    });

    socket.on('disconnect', () => {
        if (players[socket.id]) {
            delete players[socket.id];
            io.emit('disconnectPlayer', socket.id);
            console.log(`Игрок вышел: ${socket.id}`);
        }
    });
});

const PORT = 1000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`Сервер запущен`);
});
